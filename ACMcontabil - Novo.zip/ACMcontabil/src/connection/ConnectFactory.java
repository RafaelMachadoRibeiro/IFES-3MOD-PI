package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author RafaelMR
 */
public class ConnectFactory {
    
    public Connection getConnection(){
        try {
            
            return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/pi", "root", "898036");
            
        } catch (SQLException e) {
            
            return null;
        }  
    }
    
}
